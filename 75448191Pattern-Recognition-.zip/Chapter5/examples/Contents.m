% "Introduction to Pattern Recognition: A MATLAB Approach"
% S. Theodoridis, A. Pikrakis, K. Koutroumbas, D. Cavouras
%
% CHAPTER 5: book examples
%
%   example521  - Example 5.2.1
%   example531  - Example 5.3.1
%   example532  - Example 5.3.2
%   example533  - Example 5.3.3
%   IsoDigitRec - Example 5.4 (Isolated Digit Recognition System)
