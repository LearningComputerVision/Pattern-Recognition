% "Introduction to Pattern Recognition: A MATLAB Approach"
% S. Theodoridis, A. Pikrakis, K. Koutroumbas, D. Cavouras
%
% CHAPTER 3: book examples
%
%   example321 - Example 3.2.1
%   example322 - Example 3.2.2
%   example331 - Example 3.3.1
%   example341 - Example 3.4.1
%   example342 - Example 3.4.2
%   example352 - Example 3.5.2
%   example353 - Example 3.5.3
%   example361 - Example 3.6.1
