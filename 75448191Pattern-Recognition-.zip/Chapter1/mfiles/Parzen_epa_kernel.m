function [pdf]=Parzen_epa_kernel(X,h,xleftlimit,xrightlimit)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION
%   [px]=Parzen_epa_kernel(X,h,xleftlimit,xrightlimit)
% Parzen approximation of a one-dimensional pdf using a Gaussian kernel.
%
% INPUT ARGUMENTS:
%   X:              an 1xN vector, whose i-th element corresponds to the
%                   i-th data point.
%   h:              this is the step with which the x-range is sampled and
%                   also defines the volume of the epanechnikov kernel.
%   xleftlimit:     smallest value of x for which the pdf will be
%                   estimated.
%   xrightlimit:    largest value of x for which the pdf will be estimated.
%
% OUTPUT ARGUMENTS:
%   px:             a vector, each element of which contains the estimate
%                   of p(x) for each x in the range [xleftlimit,
%                   xrightlimit]. The step for x is equal to h.
%
% (c) 2010 S. Theodoridis, A. Pikrakis, K. Koutroumbas, D. Cavouras
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[l,N]=size(X);
xstep=h;
k=1;
x=xleftlimit;
z=mkernel(X,'epanechnikov');
while x<xrightlimit+xstep/2
    px(k)=0;
    for i=1:N
        xi=X(:,i);
        px(k)=px(k)+z(k)*(1/h);
    end
    px(k)=px(k)*(1/N);
    pdf(k)=px(k);
    k=k+1;
    x=x+xstep;
end


